---
title: 恋爱小屋
date: 2022-10-18 20:00:00
update: 2022-11-29 20:00:01
comments: true
password: 123456
theme: xray
message: 这里记录我和女朋友的一些事情哦，需要密码才能进入!
abstract: 只有你和我才知道密码! #密码框提示信息
wrong_pass_message: 抱歉, 这个密码看着不太对, 请再试试! #密码错误提示信息
---



