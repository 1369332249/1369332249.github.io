---
title: 关于
date: 2022-08-10 16:05:11
---

{% note warning modern %}<b>非商免字体、网图</b>等资源未经授权仅限个人使用，不得用于商业用途。本站平时仅用于交流和学习，如涉及侵权请联系站长删除对应资源，谢谢！ —— 致版权方{% endnote %}

## 0.网站自述视频🎬

<div class="about_page">
  <div align=center class="aspect-ratio">
      <iframe src="https://player.bilibili.com/player.html?aid=474023258&&page=1&as_wide=1&high_quality=1&danmaku=0" 
      scrolling="no" 
      border="0" 
      frameborder="no" 
      framespacing="0" 
      high_quality=1
      danmaku=1 
      allowfullscreen="true"> 
      </iframe>
  </div>
</div>

<br>


